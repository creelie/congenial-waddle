# Priority recheck: Wigderson's Conjecture 8

Rechecked 13 October 2026, 14:14–14:20 UTC, after the release of v1.0.0
(doi:10.5281/zenodo.23343183). The first two checks (07:45–07:55 and 09:30–09:40 UTC the same day)
are in `repository/PRIORITY-CHECK.md`.

| Source | Search | Result |
|---|---|---|
| arXiv API | arXiv:2609.29177 | still v1 only (24 September 2026) |
| arXiv API | `all:nilpotent AND all:Wigderson` | one hit, arXiv:2206.04815 (2022), which predates the conjecture |
| arXiv API | `cat:math.RA AND all:nilpotent`, newest 25 (to 9 October 2026) | Lie, Leibniz, Zinbiel and ring-theoretic papers; nothing on nilpotent-free spaces of matrices |
| Semantic Scholar | papers citing arXiv:2609.29177 | none |
| Zenodo | `"nilpotent-free"` | only this deposit (doi:10.5281/zenodo.23343183) |
| Zenodo | `Wigderson AND nilpotent`; the identifier 2609.29177 | no records |
| OpenRefute (the-omega-institute/trureturing) | issues and PRs for `Wigderson` | two results, neither about matrix spaces or arXiv:2609.29177 |
| Web search | the paper with "nilpotent-free", "counterexample", "finite field" | only the paper itself and unrelated Wigderson conjectures (log-rank, representation theory) |

Conclusion: as of 14:20 UTC on 13 October 2026 we found no other resolution of Conjecture 8, for
any field, and no earlier statement of the result proved here. The cases n = 3 over F_4, F_7, F_8
and F_9 remain open.
