# Master zip: nilpotent-free spaces of 3 × 3 matrices over F_3 (final2)

Built 13 October 2026, 14:20 UTC, from creelie/congenial-waddle, main at e15d6c7 (release v1.0.0
with its DOI recorded).

- Paper: "Nilpotent-free spaces of 3 × 3 matrices over the field with three elements",
  Deep Bhattacharjee (sole author).
- DOI of release v1.0.0: [10.5281/zenodo.23343183](https://doi.org/10.5281/zenodo.23343183);
  all versions: [10.5281/zenodo.23343182](https://doi.org/10.5281/zenodo.23343182).
- Target journal: Linear Algebra and its Applications (Elsevier). Fallbacks: Electronic Journal of
  Linear Algebra; Linear and Multilinear Algebra.

## What is proved

Every subspace of the 3 × 3 matrices over F_3 of dimension at least six contains a nonzero
nilpotent matrix, and the largest nilpotent-free dimension is five. This disproves Conjecture 8 of
Y. Wigderson, "Duality for matrix space questions" (arXiv:2609.29177), for F_3 and n = 3. The
conjecture holds for n ≤ 2 over every finite field and for n = 3 over F_2 and F_5.

All sixteen main theorems are proved in Lean 4 with Mathlib. The main theorem rests on the standard
axioms plus two Boolean equations evaluated by `native_decide` (a compiled finite search whose
soundness is proved in Lean); two independent exhaustive C programs confirm it. The other results
use the standard axioms only.

## What is open

- n = 3 over F_4, F_7, F_8 and F_9.
- Every n ≥ 4, over every finite field.
- The Gerstenhaber–Serezhkin theorem itself is not affected.

## Contents

| Path | What it is |
| --- | --- |
| `journal-LAA/laa-manuscript-final2.pdf` | Manuscript in the journal's format (elsarticle) |
| `journal-LAA/laa-manuscript-source-final2.zip` | Its LaTeX source and figures |
| `journal-LAA/cover-letter.md`, `highlights.txt` | Cover letter and highlights |
| `journal-LAA/submission-checklist.md` | Submission steps and what only the author can confirm |
| `preprint/nilpotent-free-F3-final2.pdf` | The preprint (amsart), as released |
| `preprint/nilpotent-free-F3-tex-final2.zip` | Its LaTeX source with PNG figures |
| `preprint/nilpotent-free-F3-arxiv-final2.tar.gz` | The arXiv upload |
| `PRIORITY-RECHECK-2026-10-13.md` | Priority recheck, 14:14–14:20 UTC on 13 October 2026 |
| `repository/` | The repository at e15d6c7: Lean proofs, C, C++ and Python checks, outputs, scripts and the two earlier priority checks |

## Before submitting

The manuscript already states no funding and no competing interests. Please confirm both, and give
a postal address and telephone number for the Editorial Manager account; see
`journal-LAA/submission-checklist.md`.
