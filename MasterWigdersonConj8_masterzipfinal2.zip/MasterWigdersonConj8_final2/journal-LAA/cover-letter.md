Deep Bhattacharjee
Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL)
Bhubaneswar, Odisha 751030, India
d.bhattacharjee@erl-forschung.de · itsdeep@live.com · ORCID 0000-0003-0466-750X

To the Editors, Linear Algebra and its Applications

Dear Editors,

I submit the manuscript "Nilpotent-free spaces of 3 × 3 matrices over the field with three elements" for consideration in Linear Algebra and its Applications.

In "Duality for matrix space questions" (arXiv:2609.29177, to appear in the American Mathematical Monthly), Y. Wigderson proposed to prove the Gerstenhaber–Serezhkin bound for spaces of nilpotent matrices by duality, and conjectured (Conjecture 8) that for every finite field F and every n there is a space of n × n matrices over F of dimension n² − C(n,2) whose only nilpotent element is zero. The manuscript shows that this fails for F = F_3 and n = 3: every six-dimensional space of 3 × 3 matrices over F_3 contains a nonzero nilpotent matrix, and the largest dimension of a nilpotent-free space is five. It also proves the conjecture for n ≤ 2 over every finite field and for n = 3 over F_2 and F_5, and explains the role of characteristic three through a quadric in the quotient of the trace-zero matrices by the scalars.

The proof reduces the statement to a finite search, which is carried out inside the Lean 4 proof assistant with Mathlib; the reduction, the soundness of the search and the deduction of the theorems are formally verified. Two independent exhaustive enumerations confirm the result. The preprint, the Lean development and all programs are archived at doi:10.5281/zenodo.23343183.

The manuscript is not under consideration elsewhere. There is no funding to report and no competing interest. The use of a generative AI tool is declared in the manuscript.

Yours sincerely,
Deep Bhattacharjee
