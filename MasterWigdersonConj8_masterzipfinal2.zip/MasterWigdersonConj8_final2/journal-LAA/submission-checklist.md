# Linear Algebra and its Applications: submission checklist

Manuscript: "Nilpotent-free spaces of 3 × 3 matrices over the field with three elements" (Deep Bhattacharjee, sole author).

Submit through the journal's Editorial Manager, reached from the "Submit your article" link on
https://www.sciencedirect.com/journal/linear-algebra-and-its-applications. Article type: research article.

## Files in this folder

| File | Use |
| --- | --- |
| `laa-manuscript-final2.pdf` | Manuscript for the first submission |
| `laa-manuscript-source-final2.zip` | LaTeX source (elsarticle) with the two PNG figures, for after acceptance |
| `highlights.txt` | Optional highlights, one per line, each under 85 characters |
| `cover-letter.md` | Cover letter; paste it into the submission form |

## What only the author can confirm

- [ ] No funding: the manuscript states that the research received no specific grant.
- [ ] No competing interests: the manuscript states there are none.
- [ ] Postal address and telephone number for the Editorial Manager account.
- [ ] The declaration of generative AI use at the end of the manuscript is accurate.
- [ ] The manuscript is not under consideration at another journal.

## Already done

- Abstract of three sentences, keywords, MSC 2020 codes (15A30; 15A03, 15B33, 11T99).
- Data availability statement citing the archive by its DOI, doi:10.5281/zenodo.23343183.
- Every reference and DOI checked online.
- The Lean proof and the axiom audit pass (16 theorems; see the repository README).

Fallback journals, in order: Electronic Journal of Linear Algebra; Linear and Multilinear Algebra.
